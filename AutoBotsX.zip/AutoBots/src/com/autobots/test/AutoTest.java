package com.autobots.test;

import java.io.File;
import java.io.FileInputStream;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.autobots.pages.AutoPages;


public class AutoTest {
	AutoPages p;
	WebDriver driver;
	int counter=0;
	long starttime,endtime;	
	//Logger logger=Logger.getLogger(AutoTest.class);
	Logger logger;
	
	@BeforeClass
	public void first(){
	logger=Logger.getLogger("depologs");
		
		logger.debug("Start");
		Driver dr = new Driver();
		logger.debug("Chrome");
		driver=dr.getdriver();
	}
	
	public void waiting1()throws InterruptedException
	{
		Thread.sleep(500);
	}
	
	@Test(priority=1)
	  public void testMethodRoundWay() throws Exception
	  {
		
		starttime=System.currentTimeMillis();
		AutoPages p = PageFactory.initElements(driver, AutoPages.class);
		
	    /*----------------Read From Xml File------------------------------------------*/ 
		
		File src= new File("D:/dataservlet3.0/AutoBots/Config/AutoResult.xml");
		FileInputStream fis = new FileInputStream(src);
		
		SAXReader saxreader = new SAXReader();
		Document document = saxreader.read(fis);
		
		
		p.Click(document.selectSingleNode(p.getXmlPath("roundtrip")).getText());
		waiting1();
	    p.SendValues(p.getXmlValue(document, p.getXmlData("from")),p.getXmlValue(document, p.getXmlPath("from")));
	    waiting1();
	    p.SendValues(p.getXmlValue(document, p.getXmlData("to")),p.getXmlValue(document, p.getXmlPath("to")));
	    waiting1();
	    p.Click(document.selectSingleNode(p.getXmlPath("revert")).getText());
	    waiting1();
	    p.Click(document.selectSingleNode(p.getXmlPath("openCalendar")).getText());
	    waiting1();
		p.Click(document.selectSingleNode(p.getXmlPath("dateSelector")).getText());
		waiting1();
		p.Click(document.selectSingleNode(p.getXmlPath("openreturnCalendar")).getText());
		waiting1();
		p.Click(document.selectSingleNode(p.getXmlPath("selectReturnDate")).getText());
		waiting1();
		p.Click(document.selectSingleNode(p.getXmlPath("Traveller")).getText());
		waiting1();
		p.Click(document.selectSingleNode(p.getXmlPath("Aplus")).getText());
		waiting1();
		p.Click(document.selectSingleNode(p.getXmlPath("Cplus")).getText());
		waiting1();
		p.DropDown(document.selectSingleNode(p.getXmlPath("Class")).getText(), "B");
		waiting1();
		p.CheckBox(document.selectSingleNode(p.getXmlPath("setgo")).getText());
		waiting1();
		p.Click(document.selectSingleNode(p.getXmlPath("ticket1")).getText());
		waiting1();
		p.Click(document.selectSingleNode(p.getXmlPath("ticket2")).getText());
		waiting1();
		p.Click(document.selectSingleNode(p.getXmlPath("Tbook")).getText());
		waiting1();
		   counter++;
		   logger.debug("RoundTrip got passed");
		   AutoPages.captureScreenshot("RoundTrip.jpeg");
		   logger.debug("ScreenShot Captured of Round trip booking");
     }
	
	@Test(priority=2)
	public void Redirect()
	{
		
		driver.get("https://www.goibibo.com/");
		counter++;
		logger.debug("Redirected to Goibibo Home page");
		
		AutoPages.captureScreenshot("Redirect.jpeg");
		logger.debug("ScreenShot Captured for Redirection to Goibibo Homepage");
		
	}
	
	@Test(priority=3)
	 public void testMethodOneWay() throws Exception
	  {
		
		
	 p = PageFactory.initElements(driver, AutoPages.class);

	    /*----------------Read From Xml File------------------------------------------*/ 
		
		File src= new File("D:/dataservlet3.0/AutoBots/Config/AutoResult.xml");
		FileInputStream fis = new FileInputStream(src);
		
		SAXReader saxreader = new SAXReader();
		Document document = saxreader.read(fis);
		
	    p.SendValues(p.getXmlValue(document, p.getXmlData("from")),p.getXmlValue(document, p.getXmlPath("from")));
	    waiting1();
	    p.SendValues(p.getXmlValue(document, p.getXmlData("to")),p.getXmlValue(document, p.getXmlPath("to")));
	    waiting1();
	    p.Click(document.selectSingleNode(p.getXmlPath("openCalendar")).getText());
	    waiting1();
		p.Click(document.selectSingleNode(p.getXmlPath("dateSelector")).getText());
		waiting1();
		p.Click(document.selectSingleNode(p.getXmlPath("Traveller")).getText());
		waiting1();
		p.Click(document.selectSingleNode(p.getXmlPath("Aplus")).getText());
		waiting1();
		p.Click(document.selectSingleNode(p.getXmlPath("Cplus")).getText());
		waiting1();
		p.DropDown(document.selectSingleNode(p.getXmlPath("Class")).getText(), "B");
		waiting1();
		 p.CheckBox(document.selectSingleNode(p.getXmlPath("setgo")).getText());
		 waiting1();
		 p.Click(document.selectSingleNode(p.getXmlPath("Obook")).getText());
		 waiting1();
		   counter++;
		   logger.debug("OneWay got Passed");
		   AutoPages.captureScreenshot("OneWay.jpeg");
		   logger.debug("ScreenShot Captured for OneWay trip");
   }
	@Test(priority=4)
	public void Redirect1()
	{
		
		driver.get("https://www.goibibo.com/");
		counter++;
		logger.debug("Redirected to Goibibo Homepage");
		AutoPages.captureScreenshot("Redirect1.jpeg");
		logger.debug("ScreenShot Captured for Redirection to Goibibo Homepage");
	}
	
	
	@Test(priority=5)
	  public void NegativeTest() throws Exception
	  {
		
		 p = PageFactory.initElements(driver, AutoPages.class);

	    /*----------------Read From Xml File------------------------------------------*/ 
		
		File src= new File("D:/dataservlet3.0/AutoBots/Config/AutoResult.xml");
		FileInputStream fis = new FileInputStream(src);
		
		SAXReader saxreader = new SAXReader();
		Document document = saxreader.read(fis);
		 
		 p.SendValues(p.getXmlValue(document, p.getXmlData("from")),p.getXmlValue(document, p.getXmlPath("from")));
		 waiting1();
		    p.SendValues(p.getXmlValue(document, p.getXmlData("to")),p.getXmlValue(document, p.getXmlPath("to")));
		    waiting1();
		    p.Click(document.selectSingleNode(p.getXmlPath("openCalendar")).getText());
		    waiting1();
			p.Click(document.selectSingleNode(p.getXmlPath("dateSelector")).getText());
			waiting1();
			p.Click(document.selectSingleNode(p.getXmlPath("openreturnCalendar")).getText());
			waiting1();
			p.Click(document.selectSingleNode(p.getXmlPath("selectReturnDate")).getText());
			waiting1();
		
	    System.out.println("System fails when we try to book for one way trip as it automatically select to round trip");
	    counter++;
	    logger.debug("Negative Scenario got passed");
	    
	    AutoPages.captureScreenshot("Negative.jpeg");
	    logger.debug("ScreenShot Captured for Negative Scenario");
		
	  }
@AfterClass
	public void Last() throws InterruptedException
	{
		//p.initHtmlReport(counter, starttime, endtime);
		waiting1();
		p.endTest();
		driver.quit();
	}
		
	
}
